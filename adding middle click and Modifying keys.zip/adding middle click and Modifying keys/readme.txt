Right-click: "ℇ" (script capital E)

Middle-click: "℉" (Fahrenheit sign)

Ctrl: "§" (Section sign)

Alt: "¶" (Pilcrow sign)

Shift: "©" (Copyright sign)

Escape key: Emulates the "®" character.

Delete key: Emulates the "℘" character.

Backspace key: Emulates the "ℵ" character.

Caps Lock key: Emulates the "ℒ" character.

Known bugs:

1. Browser full screen is required when using alt on most web browsers.

2. Scratch full screen We'll minimize when escape key is pressed.

5/18/2024

