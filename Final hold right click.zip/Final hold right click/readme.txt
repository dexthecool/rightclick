uses "ℇ"

Emulates right click only. Has the ability to hold.

5/18/2024