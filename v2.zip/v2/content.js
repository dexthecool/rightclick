document.addEventListener('contextmenu', function(event) {
  // Prevent the default right-click menu
  event.preventDefault();
  console.log("Right-click detected. Preventing default menu and emulating key presses.");

  // Function to emulate a key press with a hold duration
  const emulateKeyPress = (key) => {
    const eventOptions = {
      key: key,
      keyCode: key.charCodeAt(0),
      code: `Key${key.toUpperCase()}`,
      which: key.charCodeAt(0),
      bubbles: true,
      cancelable: true,
      composed: true
    };

    // Log the key being emulated
    console.log(`Emulating key press for: ${key}`);

    // Dispatch keydown and keypress events
    const activeElement = document.activeElement;
    const downEvent = new KeyboardEvent('keydown', eventOptions);
    const pressEvent = new KeyboardEvent('keypress', eventOptions);

    const dispatchedDown = activeElement.dispatchEvent(downEvent);
    const dispatchedPress = activeElement.dispatchEvent(pressEvent);
    console.log(`Dispatched keydown event for ${key}: ${dispatchedDown}`);
    console.log(`Dispatched keypress event for ${key}: ${dispatchedPress}`);

    // Hold the key down for 500 milliseconds
    setTimeout(() => {
      const upEvent = new KeyboardEvent('keyup', eventOptions);
      const dispatchedUp = activeElement.dispatchEvent(upEvent);
      console.log(`Dispatched keyup event for ${key}: ${dispatchedUp}`);
    }, 500);
  };

  // Emulate the key presses for 'o', 'l', and 'a'
  ['o', 'l', 'a'].forEach(emulateKeyPress);
  console.log("Key press emulation complete.");
});
